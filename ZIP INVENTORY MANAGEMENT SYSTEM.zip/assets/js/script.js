document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
        const inputs = form.querySelectorAll('input[required], select[required]');
        inputs.forEach(input => {
            if (!input.value) {
                e.preventDefault();
                alert('Please fill in all required fields!');
            }
        });
    });
});